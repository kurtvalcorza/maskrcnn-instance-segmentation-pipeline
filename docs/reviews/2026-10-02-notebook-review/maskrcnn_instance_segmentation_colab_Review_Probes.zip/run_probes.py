"""Review probes for tutorials/maskrcnn_instance_segmentation_colab.ipynb (row 45, prefix MRC).

Usage (from a scratch working directory that holds weights/maskrcnn-resnet50-fpn-v2/<checkpoint>.pth):
    python run_probes.py <repo_root> static      # source checks only
    python run_probes.py <repo_root> exec        # CPU direct execution, REDUCED config (see EXEC_OVERRIDES)

Direct execution is CPU-only on Windows with torch 2.14.0+cpu / torchvision 0.29.0+cpu (equal to PINS except
the +cpu wheel), install cell skipped via DIMER_NOTEBOOK_CI_PREINSTALLED=1. It is NOT a Colab run and NOT the
default configuration: N_IMAGES=8 and EPOCHS=1 so the fine-tune finishes in minutes on CPU.
"""

from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import re
import sys
import time
import traceback
from pathlib import Path

NB_REL = "tutorials/maskrcnn_instance_segmentation_colab.ipynb"
RESULTS = Path("results.json")


def load(repo: Path) -> dict:
    return json.loads((repo / NB_REL).read_text(encoding="utf-8"))


def git_blob(data: bytes) -> str:
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def save(key: str, value) -> None:
    data = json.loads(RESULTS.read_text(encoding="utf-8")) if RESULTS.exists() else {}
    data[key] = value
    RESULTS.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")


def static(repo: Path) -> None:
    raw = (repo / NB_REL).read_bytes()
    nb = json.loads(raw)
    cells = nb["cells"]
    code = [c for c in cells if c["cell_type"] == "code"]
    md_text = "\n".join("".join(c["source"]) for c in cells if c["cell_type"] == "markdown")
    compile_errors = []
    for i, c in enumerate(cells):
        if c["cell_type"] == "code":
            try:
                compile("".join(c["source"]), f"cell{i}", "exec")
            except SyntaxError as exc:  # pragma: no cover
                compile_errors.append((i, str(exc)))
    embedded = {}
    for c in cells:
        meta = c.get("metadata", {}).get("dimer", {})
        if "embedded_module" in meta:
            src = (repo / meta["embedded_module"]).read_bytes()
            embedded[meta["embedded_module"]] = {
                "metadata_sha256": meta["module_sha256"],
                "repo_file_sha256": hashlib.sha256(src).hexdigest(),
                "cell_lines": "".join(c["source"]).count("\n") + 1,
            }
    markers = {
        name: bool(re.search(pattern, md_text, re.I))
        for name, pattern in {
            "how_to_use": r"how to use this notebook",
            "intended_learner": r"intended (learner|audience)|this notebook is for",
            "roadmap": r"roadmap",
            "infrastructure_label": r"infrastructure",
            "predict_prompt": r"make a prediction|predict (what|how|whether|which)|before (you )?run",
            "expected_result_or_what_to_notice": r"expected result|what to notice|what to look for",
            "checkpoint_or_question": r"check your understanding|interpretation checkpoint|question:",
            "sample_answer": r"sample answer|<details>",
            "troubleshooting": r"troubleshoot",
            "conclusion_template": r"conclusion template|in your own words|write (a|your) conclusion",
            "glossary": r"glossary",
        }.items()
    }
    md_cells = [i for i, c in enumerate(cells) if c["cell_type"] == "markdown"]
    what_to_look = [i for i in md_cells if re.search(r"what to look for|look for", "".join(cells[i]["source"]), re.I)]
    all_src = "\n".join("".join(c["source"]) for c in cells)
    save(
        "static",
        {
            "notebook_git_blob": git_blob(raw),
            "notebook_sha256": hashlib.sha256(raw).hexdigest(),
            "n_cells": len(cells),
            "n_code": len(code),
            "n_markdown": len(cells) - len(code),
            "metadata_dimer": nb["metadata"].get("dimer"),
            "code_compile_errors": compile_errors,
            "embedded_modules": embedded,
            "guided_layer_markers": markers,
            "markdown_cells_with_look_for": what_to_look,
            "runtimes_not_measured_claim": "Runtimes are not measured in this revision" in all_src,
            "epochs_defined_in_cell": [i for i, c in enumerate(cells) if re.search(r"^EPOCHS = ", "".join(c["source"]), re.M)],
            "freeze_backbone_defined_in_cell": [i for i, c in enumerate(cells) if "FREEZE_BACKBONE = " in "".join(c["source"])],
            "rehead_cell": [i for i, c in enumerate(cells) if "from_pretrained(weights_dir=WEIGHTS_DIR, class_names=SIGN_CLASSES" in "".join(c["source"])],
            "try_next_text": re.search(r"\*\*Try next\.\*\*[^\n]*", all_src).group(0),
            "rerun_instruction_present": bool(re.search(r"re-?run (cells?|from|section)", md_text, re.I)),
            "env_var_documented_in_markdown": "DIMER_NOTEBOOK_CI_PREINSTALLED" in md_text,
            "env_var_read_in_code": "DIMER_NOTEBOOK_CI_PREINSTALLED" in all_src,
            "byod_image_opened_before_validation": "with Image.open(image_path) as handle" in all_src,
        },
    )


EXEC_OVERRIDES = {"N_IMAGES": "8", "EPOCHS": "1"}


def _sub(src: str, overrides: dict) -> str:
    for name, value in overrides.items():
        src = re.sub(rf"^{name} = .*?(  # @param.*)?$", lambda _m, n=name, v=value: f"{n} = {v}  # REVIEW OVERRIDE", src, flags=re.M)
    return src


def make_byod_dir(ns: dict, root: Path, n: int = 6) -> Path:
    import numpy as np
    from PIL import Image

    root.mkdir(parents=True, exist_ok=True)
    entries = []
    for i, rec in enumerate(ns["sign_dataset"](n, seed=123)):
        name = f"img{i}.png"
        rec["image"].save(root / name)
        masks = []
        for j, m in enumerate(rec["masks"]):
            mname = f"img{i}_mask{j}.png"
            Image.fromarray((np.asarray(m) * 255).astype("uint8")).save(root / mname)
            masks.append(mname)
        entries.append({"file": name, "boxes": [[float(v) for v in b] for b in rec["boxes"]], "labels": list(rec["labels"]), "masks": masks})
    (root / "annotations.json").write_text(json.dumps(entries), encoding="utf-8")
    return root


def run_cell(ns: dict, idx: int, src: str, log: list) -> None:
    buf = io.StringIO()
    t0 = time.time()
    status = "ok"
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(src, f"cell{idx}", "exec"), ns)
    except Exception as exc:  # noqa: BLE001
        status = f"error: {type(exc).__name__}: {exc}"
        buf.write(traceback.format_exc()[-1500:])
    log.append({"cell": idx, "status": status, "seconds": round(time.time() - t0, 1), "stdout": buf.getvalue()[-4000:]})
    print(f"cell {idx}: {status} ({log[-1]['seconds']} s)", flush=True)


def execute(repo: Path) -> None:
    os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
    nb = load(repo)
    cells = nb["cells"]
    ns: dict = {"__name__": "__main__"}
    log: list = []
    t_start = time.time()
    # Default path, reduced config: cells 3..27 (code cells only).
    for i, c in enumerate(cells):
        if c["cell_type"] != "code" or i >= 29:
            continue
        run_cell(ns, i, _sub("".join(c["source"]), EXEC_OVERRIDES), log)
    save("exec_reduced_default", {"overrides": EXEC_OVERRIDES, "cells": log, "wall_s": round(time.time() - t_start, 1)})

    # Reuse: BYOD image + dataset branch via location fields (cell 29), reduced config carried over (EPOCHS=1).
    byod_dir = make_byod_dir(ns, Path("byod_probe_ok").resolve())
    img_path = byod_dir / "img0.png"
    byod_log: list = []
    src29 = _sub("".join(cells[29]["source"]), {
        "USE_BYOD_IMAGE": "True", "BYOD_IMAGE_PATH": repr(str(img_path)),
        "USE_BYOD_DATASET": "True", "BYOD_DATASET_DIR": repr(str(byod_dir)),
    })
    run_cell(ns, 29, src29, byod_log)
    save("exec_byod_valid", {"dir_records": 6, "cells": byod_log})

    # Recovery: representative invalid inputs through the BYOD dataset/image path.
    import numpy as np
    from PIL import Image

    recovery = []

    def probe(name, fn):
        try:
            fn()
            recovery.append({"probe": name, "outcome": "ACCEPTED (no error)"})
        except Exception as exc:  # noqa: BLE001
            recovery.append({"probe": name, "outcome": f"{type(exc).__module__}.{type(exc).__name__}: {exc}"[:400]})

    bad = Path("byod_probe_bad").resolve()
    bad.mkdir(exist_ok=True)
    (bad / "annotations.json").write_text(json.dumps({"images": []}), encoding="utf-8")
    probe("annotations.json is a dict (COCO-style)", lambda: ns["read_detection_records"](bad))
    bad2 = Path("byod_probe_bad2").resolve()
    make_byod_dir(ns, bad2, n=3)
    entries = json.loads((bad2 / "annotations.json").read_text())
    entries[0]["masks"] = entries[0]["masks"][:-1] + ["missing_mask.png"]
    (bad2 / "annotations.json").write_text(json.dumps(entries))
    probe("annotations.json names a missing mask file", lambda: ns["read_detection_records"](bad2))
    bad3 = Path("byod_probe_bad3").resolve()
    make_byod_dir(ns, bad3, n=3)
    Image.new("L", (32, 32), 255).save(bad3 / "img0_mask0.png")
    probe("mask PNG with the wrong size", lambda: ns["validate_dataset"](ns["read_detection_records"](bad3), ns["SIGN_CLASSES"]))
    bad4 = Path("byod_probe_bad4").resolve()
    make_byod_dir(ns, bad4, n=3)
    entries = json.loads((bad4 / "annotations.json").read_text())
    for e in entries:
        e["boxes"] = [[b[0] / 640, b[1] / 640, b[2] / 640, b[3] / 640] for b in e["boxes"]]
    (bad4 / "annotations.json").write_text(json.dumps(entries))
    probe("normalised [0,1] boxes", lambda: ns["validate_dataset"](ns["read_detection_records"](bad4), ns["SIGN_CLASSES"]))
    probe("label outside BYOD_CLASS_NAMES", lambda: ns["validate_dataset"](ns["read_detection_records"](byod_dir), ["stop-sign"]))
    notimg = Path("not_an_image.png").resolve()
    notimg.write_text("this is text")
    def _byod_image_like_cell():
        with Image.open(notimg) as handle:
            handle.convert("RGB")
    probe("BYOD image that is not an image (cell 29 opens it before validate_inputs)", _byod_image_like_cell)
    probe("single-record BYOD dataset (split needs 2)", lambda: ns["split_dataset"](ns["read_detection_records"](byod_dir)[:1], train_fraction=0.75))
    save("recovery_probes", recovery)

    # Active learning: the 'Try next' change made the natural way (edit FREEZE_BACKBONE in Section 8, re-run the
    # fine-tune and evaluation cells) starts from the already-adapted adapter, not from the re-headed baseline.
    import torch

    key = "roi_heads.mask_predictor.mask_fcn_logits.weight"
    adapted_w = ns["adapter"].model.state_dict()[key].clone()
    first_eval = {k: ns["adapted"][k] for k in ("ap", "ap50", "mask_ap", "mask_ap50")}
    al_log: list = []
    run_cell(ns, 19, _sub("".join(cells[19]["source"]), {"FREEZE_BACKBONE": "False"}), al_log)
    run_cell(ns, 21, "".join(cells[21]["source"]), al_log)
    natural = {
        "started_from_adapted_weights": True,  # nothing re-created `adapter` between the runs
        "adapter_adapted_flag_before_rerun": True,
        "run_record_epochs": ns["run"]["epochs"],
        "run_record_freeze_backbone": ns["run"]["freeze_backbone"],
        "mask_predictor_changed_from_first_finetune": not torch.equal(adapted_w, ns["adapter"].model.state_dict()[key]),
        "eval_after_first_finetune": first_eval,
        "eval_after_natural_rerun": {k: ns["adapted"][k] for k in ("ap", "ap50", "mask_ap", "mask_ap50")},
        "total_epochs_actually_applied": 2,
    }
    # Correct path: re-run Section 7 (re-head) first, then the fine-tune with the change.
    run_cell(ns, 17, _sub("".join(cells[17]["source"]), {}), al_log)
    fresh_w = ns["adapter"].model.state_dict()[key].clone()
    natural["rehead_resets_predictor"] = not torch.equal(fresh_w, adapted_w)
    run_cell(ns, 19, _sub("".join(cells[19]["source"]), {"FREEZE_BACKBONE": "False"}), al_log)
    run_cell(ns, 21, "".join(cells[21]["source"]), al_log)
    natural["eval_after_rehead_then_rerun"] = {k: ns["adapted"][k] for k in ("ap", "ap50", "mask_ap", "mask_ap50")}
    save("active_learning", {"summary": natural, "cells": al_log})
    save("exec_total_wall_s", round(time.time() - t_start, 1))


def execute2(repo: Path) -> None:
    """Second pass (first pass segfaulted in its last fine-tune and had a probe bug in the cell-29 override).

    Reduced config N_IMAGES=6, EPOCHS=1. Order: default cells 3-21 (skipping 13 and 23-27), then the 'Try next'
    change made the natural way (FREEZE_BACKBONE=False in Section 8, re-run cells 19 and 21 only), then check that
    re-running Section 7 (cell 17) resets the predictors, then the BYOD branches via location fields (cell 29).
    """
    import torch

    os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
    cells = load(repo)["cells"]
    ns: dict = {"__name__": "__main__"}
    log: list = []
    t0 = time.time()
    ov = {"N_IMAGES": "6", "EPOCHS": "1"}
    for i in (3, 5, 7, 9, 11, 15, 17, 19, 21):
        run_cell(ns, i, _sub("".join(cells[i]["source"]), ov), log)
    key = "roi_heads.mask_predictor.mask_fcn_logits.weight"
    w_after_first = ns["adapter"].model.state_dict()[key].clone()
    first = {"run_epochs": ns["run"]["epochs"], "freeze": ns["run"]["freeze_backbone"],
             "adapted_eval": {k: round(ns["adapted"][k], 4) for k in ("ap", "ap50", "mask_ap", "mask_ap50")},
             "baseline_eval": {k: round(ns["baseline"][k], 4) for k in ("ap", "ap50", "mask_ap", "mask_ap50")}}
    flag_before = bool(ns["adapter"].adapted)
    run_cell(ns, 19, _sub("".join(cells[19]["source"]), {"FREEZE_BACKBONE": "False"}), log)
    run_cell(ns, 21, "".join(cells[21]["source"]), log)
    natural = {"adapter_already_adapted_before_rerun": flag_before,
               "run_record_after_rerun": {"epochs": ns["run"]["epochs"], "freeze_backbone": ns["run"]["freeze_backbone"]},
               "epochs_actually_applied_to_adapter": 2,
               "adapted_eval_after_rerun": {k: round(ns["adapted"][k], 4) for k in ("ap", "ap50", "mask_ap", "mask_ap50")},
               "baseline_row_printed_is_original": {k: round(ns["baseline"][k], 4) for k in ("ap", "ap50", "mask_ap", "mask_ap50")}}
    del ns["run"]
    run_cell(ns, 17, _sub("".join(cells[17]["source"]), ov), log)
    natural["rehead_cell17_resets_predictor"] = not torch.equal(w_after_first, ns["adapter"].model.state_dict()[key])
    natural["adapted_flag_after_rehead"] = bool(ns["adapter"].adapted)
    save("active_learning", {"first": first, "natural_rerun": natural})
    byod_dir = make_byod_dir(ns, Path("byod2_ok").resolve(), n=4)
    src29 = _sub("".join(cells[29]["source"]), {
        "USE_BYOD_IMAGE": "True", "BYOD_IMAGE_PATH": repr(str(byod_dir / "img0.png")),
        "USE_BYOD_DATASET": "True", "BYOD_DATASET_DIR": repr(str(byod_dir)),
    })
    run_cell(ns, 29, src29, log)
    save("exec2", {"overrides": ov, "cells": log, "wall_s": round(time.time() - t0, 1),
                   "byod_outputs": sorted(p.name for p in Path("outputs").iterdir())})


if __name__ == "__main__":
    repo_root = Path(sys.argv[1])
    mode = sys.argv[2]
    if mode == "static":
        static(repo_root)
    elif mode == "exec":
        execute(repo_root)
    elif mode == "exec2":
        execute2(repo_root)
    print("done", mode)
